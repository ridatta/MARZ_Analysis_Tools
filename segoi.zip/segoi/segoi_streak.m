% segoi streak
clc; close all; clear;

% fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\z3697\shot_data\SEGOI\downline_data\z3697-leg1-shot.hdf');

% 
% info = hdfinfo(fname);
%  data= hdfread(fname,'fore');
 
fname = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN group/Data/Z/MARZ/Shots/MARZ1_z3697/SEGOI/processed_images/HDF5/z3697_SEGOI_Leg1_streak.hdf5');
info = h5info(fname);
img = h5read(fname,'/image');
xpts = h5read(fname,'/xpts');
ypts = h5read(fname,'/ypts');
 
 
 % make scatter plot
 
 [xx,yy] = meshgrid(xpts,ypts);
 figure
  colormap(gray);
  xx = xx - 2800;
 scatter(xx(:),yy(:),10,img(:)./max(img(:)),'s','filled','HandleVisibility','off');
 xlim([xpts(1),xpts(end)]-2800); ylim([10.5,20]);
 xlabel('time [ns]'); ylabel('Distance from wires [mm]');
 formatPlots(900,40);
 set(gcf,'Position',[0 0 1800 600]);
 
 grid on; grid('Minor');
 set(gca,'TickDir','out')
 set(gca,'Layer','top','GridColor','r','GridAlpha',0.1,...
    'MinorGridLineStyle','-','MinorGridColor',[.92 .51 .93],'MinorGridAlpha',0.1)

 saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3697/');
exportgraphics(gcf, [saveDir,'leg1_streak_segoi.tiff']);

save([saveDir 'segoi_streak.mat'],'img','xx','yy');

%% Lineouts

clc; close all; clear;
 saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
load([saveDir 'segoi_streak.mat'],'img','xx','yy');
  xx = xx + 2800;
tid = 3120:20:3170;
figure
for ii = 1:numel(tid)
    Yi = linspace(min(yy(:)),max(yy(:)),1803); % position
    Xi = tid(ii)* ones(size(Yi)); % time
    xstp = 1; N = 5;
    out = getavgLineout(xx,yy,img,Xi,Yi,xstp,N);
    plot(Yi,out,'DisplayName',['t = ' num2str(Xi(1)-2800) ' ns'],'LineWidth',2,'Color',[sqclr('b',2*ii),0.8]); hold on;
end
xlabel('Position [mm]'); ylabel('Counts [arb. units]'); 
xlim([min(Yi),max(Yi)]);
grid on;
formatPlots(900,30); set(gcf,'Position',[0 0 1200 500]);
exportgraphics(gcf, [saveDir,'leg1_streak_segoi_lineout.tiff']);



function out = getavgLineout(xx,yy,data,Xq,Yq,xstp,N)
    out = 0;
    for ii = 0:N
        out = out + interp2(xx,yy,data,Xq+N*xstp-ii*xstp,Yq); 
    end
    out = out / (2 * N);
end
