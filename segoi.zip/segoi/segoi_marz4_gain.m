clc; close all; clear;

% Caluclates the gain required for SEGOI based on solid angle and
% magnification of teh SEGOI system

% MARZ 2
D = 75e-3; % m
f = 400e-3; % focal length
R = 1; % m
solid_ang1 = pi * D^2 / 4 / R^2; 
M1 = 0.5;

fprintf('Solid angle(MARZ2-3) [sr] = %1.3s\n',solid_ang1);

% MARZ 4
D = 75e-3; % m
f = 500e-3; % focal length
R = 0.6; % m
solid_ang2 = pi * D^2 / 4 / R^2; 
M2 = 0.69;

fprintf('Solid angle [sr] = %1.3s\n',solid_ang2);

G1 = 32;
G2 = M2 / M1 * solid_ang1 / solid_ang2 * G1;

fprintf('Gain for MARZ 4 [-] = %1.3f\n',G2);

%%
% Calculate teh absolute gain from the relative gain

clc; close all;
rel = [128,32,8,2,64,16,4,1];
ab = [362,247,137,32,304,192,84,1];

figure
semilogx(rel,ab,'ok',linewidth =2,markerfacecolor='k',markersize=10,DisplayName='From MARZ2');
xlabel('relative gain');

ylabel('absolute gain');
grid()
formatPlots(900,2);
legend('box','on','location','southeast')
xticks(sort(rel));
yticks(0:50:400)
ylim([0,inf]);



% fit

r = linspace(1,128,256);
P = polyfit(log(rel),ab,1);
a = polyval(P,log(r));

fprintf('a = %1.2f ln(r) + %1.2f\n',P(1),P(2));

hold on;
semilogx(r,a,'-.r',DisplayName='fit',linewidth=3);

G2 = 16;
fprintf('G2 = %1.0f, a = %1.3f\n',G2,polyval(P,log(G2)));