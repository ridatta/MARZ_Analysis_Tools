% SEGOI
clc; close all; clear;

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3697/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end


fname = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN group/Data/Z/MARZ/Shots/MARZ1_z3697/SEGOI/downline_data/z3697-goi-shot.hdf');
% fname = checkDir('C:\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\z3697\shot_data\SEGOI\goi_preshot\goi-probe-675-reticle.hdf');

for ii = 1:8 % Read data

data{ii} = hdfread(fname,['DS', num2str(ii)]);

[m,n] = size(data{ii});

end

segoi_idx = 1:8;
frame_idx = [4,3,2,1,5,6,7,8];

% sort
segoi_idx = segoi_idx(frame_idx); 
data = data(frame_idx);

tidx = 3125+linspace(0,49,8);
gain = [424	141	307	195	365	301	137	435]; % sorted by frame

% montage(data,'Size',[2,4]); colormap('hot'); colorbar(); caxis([0,4000]);

fig = figure();
tlo = tiledlayout(fig,2,4); % Use loose to space it out
for i = 1:numel(data)
    ax = nexttile(tlo); 
    imshow(data{i});
    axis('off');
    colormap('hot'); colorbar(); caxis([0,4000]);

    title([num2str(tidx(i)) ' ns gain = ' num2str(gain(i)) ' GOI', num2str(segoi_idx(i)) ]);
end
set(gcf,'Position',[0 0 1850 750]);
sgtitle('z3697 SEGOI 8-frame Preshot');

saveas(gcf,[saveDir 'segoi_raw_8frame-preshot.png']);
save([saveDir 'segoi.mat'],'data','frame_idx','gain','tidx','segoi_idx');

%% Load pre-shot

% open pre-shot with reticle (0.5mm separation)
clc; close all; clear;

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3697/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end

load([saveDir 'segoi.mat'],'data','frame_idx','segoi_idx');

fname = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN group/Data/Z/MARZ/Shots/MARZ1_z3697/SEGOI/goi_preshot/goi-inChamberReticle.hdf');

for ii = 1:8 % Read data
preshot_reticle{ii} = hdfread(fname,['DS', num2str(ii)]);
end
preshot_reticle = preshot_reticle(frame_idx); % sort by frame idx

fnums = [2,4,7]; % frame numbers to read

scale_data = {}; new = true;

for ii = 1:numel(fnums)
fnum = fnums(ii);
figure
imshow(preshot_reticle{fnum}); 
title(['SEGOI Pre-shot (w/ Reticle), Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',24);
axis('off'); colormap(gray);
colorbar(); caxis([0,4e3]); hold on;


% Select points for alignment and scale
if new == true
[Xi,Yi] = getpts(); % select origin then points on the 7 mm circle
end

plot(Xi(1),Yi(1),'xg','HandleVisibility','off'); hold on;
plot([Xi(1),Xi(2)],[Yi(1),Yi(2)],'-c','HandleVisibility','off');
plot([Xi(1),Xi(3)],[Yi(1),Yi(3)],'-m','HandleVisibility','off');

% length of lines 
l1 = sqrt( (Xi(2) - Xi(1)).^2 + (Yi(2) - Yi(1)).^2); % [px]
l2 = sqrt( (Xi(3) - Xi(1)).^2 + (Yi(3) - Yi(1)).^2); % [px]
scl1 = l1 / 3.5; % [px/mm] % calculate scale
scl2 = l2 / 3.5; % [px/mm]

% Calculate angle

th1 = atand( (Yi(2) - Yi(1)) ./ (Xi(2) - Xi(1))); % deg,
th2 = atand( (Yi(3) - Yi(1)) ./ (Xi(3) - Xi(1))); % deg

% Text on image
text(50,150,[num2str(l1,3) ' px, ' ...
    num2str(scl1,3) ' px/mm, ', ...
    num2str(1/scl1*1e3,3), ' um/px, ', ...
    num2str(th1,3) ' deg'],'Color','c','FontSize',24);
text(50,200,[num2str(l2,3) ' px, ' ...
    num2str(scl2,3) ' px/mm, ',...
    num2str(1/scl2*1e3,3), ' um/px, '...
    num2str(th2,3), ' deg'],'Color','m','FontSize',24);

text(mean([Xi(1),Xi(2)]),mean([Yi(1),Yi(2)]),'3.5 mm','Color','c','FontSize',24);
text(mean([Xi(1),Xi(3)]),mean([Yi(1),Yi(3)]),'3.5 mm','Color','m','FontSize',24);

% save
out.scl = [scl1,scl2];
out.sclunits = 'px/mm';
out.th = [th1,th2];
out.ogn = [Xi(1),Yi(1)]; 
scale_data{fnum} = out;

% save image
saveDir = checkDir('/Users/Rishabh/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/scale_data/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end
    exportgraphics(gcf, [saveDir, 'frame = ' num2str(fnum) '.tiff']); 
end


% save to mat file
saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
save([saveDir 'segoi.mat'],'scale_data','-append');

%% Load segoi image and rotate + scale
clc; close all; clear;

saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
load([saveDir 'segoi.mat']);

fnums= [2,4,7]; scale_data_2 = {};
for ii = 1:numel(fnums)
fnum = fnums(ii); 
img = data{fnum}; % shot image
% preshot image
fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\z3697\shot_data\SEGOI\goi_preshot\goi-probe-675.hdf');
pre_shot = hdfread(fname,['DS', num2str(frame_idx(fnum))]);

fname = checkDir('/Users/Rishabh/Dropbox (MIT)/PUFFIN group/Data/Z/z3697/shot_data/SEGOI/goi_preshot/goi-inChamberReticle.hdf');
pre_shot_reticle = hdfread(fname,['DS', num2str(frame_idx(fnum))]);

% figure
% imshow(pre_shot_reticle); [m,n] = size(img);
% title(['SEGOI Shot, Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
% set(gca,'FontSize',24);
% axis('off'); colormap(gray);
% colorbar(); caxis([0,4e3]); hold on;

% Rotate image
angle = mean([scale_data{fnum}.th(1), -1*(90-scale_data{fnum}.th(2))]);

pre_shot_reticle = imrotate(pre_shot_reticle,angle,'crop');
size(pre_shot_reticle)
pre_shot_reticle = imcrop(pre_shot_reticle,[ 0, 0 ,1000, 1000]);
size(pre_shot_reticle)

figure
imshow(pre_shot_reticle);
title(['SEGOI Shot, Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',24);
axis('off'); colormap(gray);
colorbar(); caxis([0,4e3]); hold on;

% Re-scale

% Select points for alignment and scale
if true
[Xi,Yi] = getpts(); % select origin then points on the 7 mm circle
end

plot(Xi(1),Yi(1),'xg','HandleVisibility','off'); hold on;
plot([Xi(1),Xi(2)],[Yi(1),Yi(2)],'-c','HandleVisibility','off');
plot([Xi(1),Xi(3)],[Yi(1),Yi(3)],'-m','HandleVisibility','off');

% length of lines 
l1 = sqrt( (Xi(2) - Xi(1)).^2 + (Yi(2) - Yi(1)).^2); % [px]
l2 = sqrt( (Xi(3) - Xi(1)).^2 + (Yi(3) - Yi(1)).^2); % [px]
scl1 = l1 / 3.5; % [px/mm] % calculate scale
scl2 = l2 / 3.5; % [px/mm]

% Calculate angle

th1 = atand( (Yi(2) - Yi(1)) ./ (Xi(2) - Xi(1))); % deg,
th2 = atand( (Yi(3) - Yi(1)) ./ (Xi(3) - Xi(1))); % deg

% Text on image
text(50,700,[num2str(l1,3) ' px, ' ...
    num2str(scl1,3) ' px/mm, ', ...
    num2str(1/scl1*1e3,3), ' um/px, ', ...
    num2str(th1,3) ' deg'],'Color','c','FontSize',16);
text(50,750,[num2str(l2,3) ' px, ' ...
    num2str(scl2,3) ' px/mm, ',...
    num2str(1/scl2*1e3,3), ' um/px, '...
    num2str(th2,3), ' deg'],'Color','m','FontSize',16);

text(mean([Xi(1),Xi(2)]),mean([Yi(1),Yi(2)]),'3.5 mm','Color','c','FontSize',24);
text(mean([Xi(1),Xi(3)]),mean([Yi(1),Yi(3)]),'3.5 mm','Color','m','FontSize',24);

% save
out.scl = [scl1,scl2];
out.sclunits = 'px/mm';
out.th = [th1,th2];
out.ogn = [Xi(1),Yi(1)]; 
scale_data_2{fnum} = out;

% save image
saveDir = checkDir('/Users/Rishabh/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/scale_data/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end
    exportgraphics(gcf, [saveDir, 'frame = ' num2str(fnum) '-rotated.tiff']);
end

saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
save([saveDir 'segoi.mat'],'scale_data_2','-append');

%% Load and rotate shot images

clc; close all; clear;

saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
load([saveDir 'segoi.mat']);

fnums = [2,4,7];

processed_shot = {};

% Shot Images
for ii = 1:numel(fnums)
    figure
    fnum = fnums(ii);
    img = data{fnum}; % shot image
    % Rotate image
    angle = mean([scale_data{fnum}.th(1), -1*(90-scale_data{fnum}.th(2))]); % rotation angle
    img = imrotate(img,angle,'crop'); % roate shot image
    % Crop % center image
    %crp_rect = [scale_data_2{fnum}.ogn(1)-200,scale_data_2{fnum}.ogn(2)-200,...
       % 850,850];
    img = imcrop(img,[ 0, 0 ,1000, 1000]);
 
    
    crp_rect = [scale_data_2{fnum}.ogn(1)-350,scale_data_2{fnum}.ogn(2)-850/2,...
       850,850];
   img = imcrop(img,crp_rect);
    
    % show shot image
    imshow(img);
    title(['z3697 SEGOI Shot - Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
    set(gca,'FontSize',20);
    axis('on'); colormap('gray');
    colorbar(); caxis([0,4e3]); hold on;
%     plot(350,850/2,'xg','MarkerSize',24); % Reticle center
   set(gca,'Ydir','normal');
    xlabel('Distance from wires (mm)'); ylabel('y (mm)');
    
    
    % Convert labels to mm
    scl = mean(scale_data_2{fnum}.scl); % px/mm
    
%      % streak line 1mm from reticle center
%          h = shadedErrorBar([0,850],[850/2-scl*1,850/2-scl*1],scl*0.25,'lineProps',{'Color','g','HandleVisibility','off'});
%     plot([0,850],[850/2-scl*1,850/2-scl*1],'Color','g','HandleVisibility','off');
    
    xlbls = 0.3+(-5:1:5); ylbls = -5:1:5;  % [mm]
         ogn = [332,505];
    xlbls_px = round(xlbls * scl) + ogn(1); ylbls_px = round(ylbls * scl) + ogn(2);  % px
    xticks(xlbls_px); yticks(ylbls_px);
    xticklabels(num2str(xlbls'+13.7)); yticklabels(num2str(ylbls'));
    
    % Save image
    saveDir = checkDir('/Users/Rishabh/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
    exportgraphics(gcf, [saveDir, 'frame = ' num2str(fnum) '-shot_rotated.tiff']);
    processed_shot{fnum} = img;
    
    minA = min(img(:));
    A = double(img - minA) ./ double( max(img(:)) - minA);
    imwrite( A,  [saveDir, 'frame = ' num2str(fnum) '-shot_raw.tiff']);
    
    
end

proccessed_preshot = {};
% pRE-Shot Images
for ii = 1:numel(fnums)
    
    figure
    fnum = fnums(ii);
    % preshot image
    fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\z3697\shot_data\SEGOI\goi_preshot\goi-probe-675.hdf');
    pre_shot = hdfread(fname,['DS', num2str(frame_idx(fnum))]);

    % Rotate image
    angle = mean([scale_data{fnum}.th(1), -1*(90-scale_data{fnum}.th(2))]); % rotation angle
    pre_shot = imrotate(pre_shot,angle,'crop'); % roate shot image
    % Crop % center image
    %crp_rect = [scale_data_2{fnum}.ogn(1)-200,scale_data_2{fnum}.ogn(2)-200,...
       % 850,850];
    pre_shot = imcrop(pre_shot,[ 0, 0 ,1000, 1000]);
    size(pre_shot)
    
    crp_rect = [scale_data_2{fnum}.ogn(1)-350,scale_data_2{fnum}.ogn(2)-850/2,...
       850,850];
   pre_shot = imcrop(pre_shot,crp_rect);
    
    % show shot image
    imshow(pre_shot);
    title(['z3697 SEGOI Pre-Shot - Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
    set(gca,'FontSize',20);
    axis('on'); colormap('gray');
    colorbar(); caxis([0,4e3]); hold on;
%     plot(350,850/2,'xg','MarkerSize',24); % Retcle center
   set(gca,'Ydir','normal');
    xlabel('Distance from wires (mm)'); ylabel('y (mm)');
    
  
     % streak line 1mm from reticle center, accurate iwthin 0.5mm

%     h = shadedErrorBar([0,850],[850/2-scl*1,850/2-scl*1],scl*0.25,'lineProps',{'Color','g','HandleVisibility','off'});
    
    xlbls = 0.3+(-5:1:5); ylbls = -5:1:5;  % [mm]
         ogn = [332,505];
    xlbls_px = round(xlbls * scl) + ogn(1); ylbls_px = round(ylbls * scl) + ogn(2);  % px
    xticks(xlbls_px); yticks(ylbls_px);
    xticklabels(num2str(xlbls'+13.7)); yticklabels(num2str(ylbls'));
    
    % Save image
    saveDir = checkDir('/Users/Rishabh/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
    exportgraphics(gcf, [saveDir, 'frame = ' num2str(fnum) '-preshot_rotated.tiff']);
    processed_preshot{fnum} = pre_shot;
    
end

save([saveDir 'segoi.mat'],'processed_preshot','processed_shot','-append');

%% Bow shock processing

clc; close all; clear;

saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
load([saveDir 'segoi.mat']);

fnum = 7;
gain = 1;
img = processed_shot{fnum};

% imwrite(img,[saveDir 'segoi-4.png'],'PNG');

% show image
figure('units','normalized','outerposition',[0 0 1 1])
imshow(img*gain);
title(['z3697 SEGOI Shot - Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',20);
axis('on'); colormap('gray');
colorbar(); caxis([0,4e3]); hold on;
set(gca,'Ydir','normal');
xlabel('Distance from wires (mm)'); ylabel('y (mm)');
xlbls = 0.3+(-5:1:5); ylbls = -5:1:5;  % [mm]
ogn = [332,505];
scl = mean(scale_data_2{fnum}.scl); % px/mm
xlbls_px = round(xlbls * scl) + ogn(1); ylbls_px = round(ylbls * scl) + ogn(2);  % px
xticks(xlbls_px); yticks(ylbls_px);
xticklabels(num2str(xlbls'+13.7)); yticklabels(num2str(ylbls'));
hold on;
% 

saveas(gcf,[saveDir 'segoi-' num2str(fnum) '.png']);

% [xi,yi] = getpts();
% 
% [yi,idx] = sort(yi); xi = xi(idx);
% plot(xi,yi,'--g','linewidth',2);





%% Bow shock


clc; close all; clear;

saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end

load([saveDir 'segoi.mat'],'data','frame_idx','gain','tidx','segoi_idx');

fnum = 7;

figure % Plot frame
img = data{fnum};

imagesc(img); 
axis('off');
colormap('hot'); colorbar(); caxis([0,4e3]);

title([num2str(tidx(fnum)) ' ns gain = ' num2str(gain(fnum)) ' GOI', num2str(segoi_idx(fnum)) ]);

saveas(gcf,[saveDir 'segoi_frame' num2str(fnum) '.png']);

% load preshot images

fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\z3697\shot_data\SEGOI\goi_preshot\goi-probe-675.hdf');
pre_shot = hdfread(fname,['DS', num2str(frame_idx(fnum))]);

figure

montage({pre_shot,img}); colormap('hot'); colorbar(); caxis([0,4e3]);
title([num2str(tidx(fnum)) ' ns gain = ' num2str(gain(fnum)) ' GOI', num2str(segoi_idx(fnum)) ' Pre-shot (left) Shot (right)']);

% Rotate images

angle = -70;
pre_shot = imrotate(pre_shot,angle); img = imrotate(img,angle);

figure

montage({pre_shot,img}); colormap('hot'); colorbar(); caxis([0,4e3]);
title([num2str(tidx(fnum)) ' ns gain = ' num2str(gain(fnum)) ' GOI', num2str(segoi_idx(fnum)) ' Pre-shot (left) Shot (right)']);
saveas(gcf,[saveDir 'segoi_frame' num2str(fnum) '-montage-rotated.png']);
% % Composite image
% C = imfuse(pre_shot,img); % infused image
% 
% figure
% imagesc(C); colormap('gray'); colorbar(); caxis([0,4e3]);

figure
imagesc(img); axis('off');
colormap('hot'); colorbar(); caxis([0,4e3]);

title([num2str(tidx(fnum)) ' ns gain = ' num2str(gain(fnum)) ' GOI', num2str(segoi_idx(fnum)) ]);




% calibration
% 
% figure
% imagesc(pre_shot); axis('off');
% colormap('hot'); colorbar(); caxis([0,4e3]);
% 
% title([num2str(tidx(fnum)) ' ns gain = ' num2str(gain(fnum)) ' GOI', num2str(segoi_idx(fnum)) ]);
% 
% % [x1,y1] = getpts;
% % 
% % scl = (x1(2) - x1(1)); % [px/mm]

scl = 103/1; %px/mm
ogn = [0,0];

close all;

 figure();
[xx,yy] = showMap(pre_shot,scl,ogn,[2,11],[4,11],[0,4000]); % [mm]
colormap('hot'); colorbar(); caxis([0,4e3]); axis off;
set(gcf,'Position',[0 0 1200 1200]);
title([num2str(tidx(fnum)) ' ns gain = ' num2str(gain(fnum)) ' GOI', num2str(segoi_idx(fnum)) ]);

saveas(gcf,[saveDir 'segoi_frame' num2str(fnum) 'preshot-rotated.png']);

f1 = figure();
[xx,yy] = showMap(img,scl,ogn,[2,11],[4,11],[0,4000]); % [mm]
colormap('hot'); colorbar(); caxis([0,4e3]);
set(gcf,'Position',[0 0 1200 1200]); axis off;
title([num2str(tidx(fnum)) ' ns gain = ' num2str(gain(fnum)) ' GOI', num2str(segoi_idx(fnum)) ]);
saveas(gcf,[saveDir 'segoi_frame' num2str(fnum) '-rotated.png']);



% figure(f1); % auto detection
% plotOnImage([x1,x2],[y1,y1],scl*1,ogn,'-g'); hold on;
% plotOnImage([x1,x2],[y2,y2],scl*1,ogn,'-g'); hold on; 
% plotOnImage([x1,x1],[y1,y2],scl*1,ogn,'-g'); hold on;
% plotOnImage([x2,x2],[y1,y2],scl*1,ogn,'-g'); hold on;
% 
% fg = figure();
% Xq = linspace(x1,x2,100); ii = 1;
% for yval = y1:0.5:y2
% 
% Yq = yval * ones(size(Xq)); 
% figure(f1);
% plotOnImage(Xq,Yq,scl*1,ogn,'--c'); hold on;
% 
% % lineout
% img = double(img);
% out = interp2(xx,yy,img,Xq,Yq); 
% 
% figure(fg);
% plot(Xq,out,'color',sqclr('b',ii)); hold on;
% xlabel('Xq (mm)'); ylabel('Counts');
% ii= ii+1;
% end
new = false;
if new
[xs,ys] = getpts;
xs = xs(1:end-1); ys = ys(1:end-1);
save([saveDir 'segoi_frame' num2str(fnum) 'shockpts.mat'],'xs','ys');
else
load([saveDir 'segoi_frame' num2str(fnum) 'shockpts.mat'],'xs','ys');
end

% Plot shock angle
figure
yyaxis left
plot(xs,-1*ys,'k--X','DisplayName','Shock'); hold on;

yyaxis right
ylabel('Opening angle, degrees');
dydx = diff(ys)./diff(xs);
th = atand(dydx);
plot(xs(2:end),th,'r','DisplayName','\alpha/2'); hold on; grid on; formatPlots(900);

set(gcf,'Position',[0 0 1.5 1]*900);

saveas(gcf,[saveDir 'segoi_frame' num2str(fnum) '-shock.png']);

%% save raw image and gradient as tiff

clc; close all; clear;

clc; close all; clear;

saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
load([saveDir 'segoi.mat']);

fnum = 4;
img = processed_shot{fnum};

% show image & save
figure('units','normalized','outerposition',[0 0 1 1])
imshow(img);
colormap('gray'); caxis([0,4e3]); hold on;
set(gca,'Ydir','normal');
exportgraphics(gcf, [saveDir, 'frame = ' num2str(fnum) '-shot_raw.tiff']);

img_sm = wiener2(img,[1,1]*25);

figure
imshowpair(img, img_sm,'montage'); hold on;
% set(gca,'Ydir','normal');

[Gx, Gy] = imgradientxy(img_sm);

figure
imshow(Gy); colormap('gray');hold on;
set(gca,'ColorScale','log'); 
caxis([1,1e3])
% set(gca,'Ydir','normal');
exportgraphics(gcf, [saveDir, 'frame = ' num2str(fnum) '-shot_gradient.tiff']);




%% Get shock angle from detected shock
clc; close all; clear;
saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
fnum = 4;

img = imread('/Users/Rishabh/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/frame = 4-shot_raw_traced.tif');

f1 = figure();
imshow(img); axis on; hold on; set(gca,'Ydir','Normal');

figure
frnt = img(:,:,2)-img(:,:,1);
imshow(frnt); axis on;

[idy,idx] = find(frnt ~= 0);

figure
ax1 = subplot(2,1,1);

[idy,id] = sort(idy); idx = idx(id);

shft_x = min(idx); 

idx = idx - min(idx); % center

[~,num] = min(idx);

shft_y = idy(num);

idy = idy - idy(num);

% center
%idx = idx - min(idx);

plot(idy,idx,'Linewidth',4,'DisplayName','Detected Shock'); hold on;

ylabel('x (px)'); 
set(gca,'Xticklabel','');

P = polyfit(idy,idx,6); % x vs y
ys = linspace(min(idy),max(idy),100);
xs = polyval(P,ys);
dxdy = polyder(P); 
ang = atand(polyval(dxdy,ys));
ang(ang < 0) = -1* ang(ang < 0);
alpha = 2*(90 - ang);

plot(ys,xs,'Linewidth',2,'Color','r','DisplayName','fit');
grid on; legend('location','northwest'); formatPlots(900,16);

ax2 = subplot(2,1,2);
plot(ys,ang,'Linewidth',2,'DisplayName','tan^{-1} (dx/dy)'); ylim([0,90]); hold on;
plot(ys,alpha/2,'Linewidth',2,'DisplayName','0.5 \times Opening Angle'); ylim([0,90]);
grid on; legend('location','southwest');
xlabel('y (px)'); ylabel('Angle (degrees)'); ylim([0,90]);
formatPlots(900,16);

set(gcf,'Position',[360    51   667   500])
exportgraphics(gcf, [saveDir, 'frame = ' num2str(fnum) '-openingAngle.png']);

pause(2);
% show shock on image

saveDir = checkDir('/Users/Rishabh//Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/processed/');
load([saveDir 'segoi.mat']);


fnum = 4;
data = processed_shot{fnum};

% 
figure(f1);
plot(xs+shft_x,ys+shft_y,'Linewidth',2,'Color','r','DisplayName','Shock'); % shock

pause(1);

% show image
figure('units','normalized','outerposition',[0 0 1 1])
imshow((data)); hold on; % image
set(gca,'Ydir','normal');
plot(xs+shft_x,ys+shft_y,'Linewidth',2,'Color',[1,0,0,0.5],'DisplayName','Shock'); % shock
title(['z3697 SEGOI Shot - Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',20);
axis('on'); colormap('gray');
colorbar(); caxis([0,4e3]); hold on;
xlabel('Distance from wires (mm)'); ylabel('y (mm)');
xlbls = 0.3+(-5:2:5); ylbls = -5:2:5;  % [mm]
ogn = [332,505];
scl = mean(scale_data_2{fnum}.scl); % px/mm
xlbls_px = round(xlbls * scl) + ogn(1); ylbls_px = round(ylbls * scl) + ogn(2);  % px
xticks(xlbls_px); yticks(ylbls_px);
xticklabels(num2str(xlbls'+13.7)); yticklabels(num2str(ylbls'));
hold on; legend();
exportgraphics(gcf, [saveDir, 'frame = ' num2str(fnum) '-shock.tiff']);
% formatPlots(900,16);






   
