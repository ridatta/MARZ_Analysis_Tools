%% gain setting calculator

% Caluclates teh nominal gain for SEGOI

clc; close all;

A1=0.0135;          % fit parameter
A2=-2.259e-6;       % fit parameter
gain0=250;          % reference gain
gate0=1e3;          % reference gate (ps)
amp_ideal = 48/32;    % amplification of counts relative to reference (0.5 = half the sensitivity)
gate=1e3;           % gate of current setting (ps)
 
for gain = 1:1000
    counts = 1;
    amp = counts*exp(A1*gain+A2*gain^2)/exp(A1*gain0+A2*gain0^2)*gate/gate0;
    if amp>amp_ideal
        break
    end
end
fprintf("\n The gain setting is: ")
fprintf(num2str(gain))
fprintf("\n")