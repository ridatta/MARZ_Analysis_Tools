README

R. Datta 
7/30/2024

This code processes the raw data from SEGOI.

Use this code to:

(1) Load and plot raw streak data and 2D image data.
(2) Rotate, scale, and plot 2D self-emission images
(3) Get spatial and time claibration for streak image.

The main scripts are:

segoi_streak_marz4.mlx - Analysis of MARZ 4 Streak Image Data
segoi_8frame_marz4.m - Analysis of MARZ 2D Self-Emission Data

Please see these scripts for detailed instructions and methodology.

Important considerations:

(1) Ensure input directory path containing raw data and/or metadata points to the correct location on your machine.
    
The checkDir() function is NOT required.

(2) Ensure save directory path where processed data is stored is accurate on your machine.

The checkDir() function is NOT required.

(3) Additional libraries may be required for some analysis. 

These can be downloaded from https://github.com/ridatta/PlasmaFormulary.git. 

Use addpath(/path/to/downloaded/code/) to add the downloaded libraries to the MATLAB workspace.