% segoi streak
clc; close all; clear;

% fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\z3697\shot_data\SEGOI\downline_data\z3697-leg1-shot.hdf');

% 

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3978/processed/');
fname = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN group/Data/Z/MARZ/Shots/MARZ4_z3978/SEGOI/shot_data/leg2/z3978-leg2-shot-corrected.hdf');
info = hdfinfo(fname);
data = hdfread(fname,'fore');

figure
imagesc(data)
colormap gray
colorbar
caxis([0,12e3])

saveas(gcf, [saveDir,'leg2_streak_segoi.png']);
 

%% GET Time Calibration

clc; close all; clear;

% Load shot image

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3978/processed/');
fname = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN group/Data/Z/MARZ/Shots/MARZ4_z3978/SEGOI/shot_data/leg2/z3978-leg2-shot-corrected.hdf');
info = hdfinfo(fname);
data = hdfread(fname,'fore');

figure
imagesc(data)
colormap gray
colorbar
caxis([0,12e3])

yticks(0:100:2000)

axs = gca;
axs.YDir = 'normal'

out = mean(data(275:350,:),1);
t_px = 1:size(data,2);

figure
plot(t_px,out); hold on;
xlim([0,max(t_px)]);
xlabel('t [px]');
formatPlots(900,2);


[PKS,LOCS] = findpeaks(out,'MinPeakProminence',250,'MinPeakWidth',3);

plot(t_px(LOCS),PKS,'o',color='r')

t0 = 190; % known, ns
pk_idx = 1:numel(PKS);
tvals = t0 + (pk_idx-1) * 2; % ns

figure
plot(t_px(LOCS),tvals,'o'); hold on;
formatPlots(900,2);
grid();
xlabel('px'); ylabel('ns');
legend('off');

P = polyfit(t_px(LOCS),tvals,1);

px = linspace(t_px(LOCS(1)),t_px(LOCS(end)),100);

px2ns = @(px) P(1) * px + P(2);


tt = px2ns(px);

plot(px,tt,'-r');




save([saveDir 'segoi_streak.mat'],'px2ns','data'); % save the time calibration function


%% Get space calibration

clc;  clear; close all;

inDir = checkDir('C:\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\MARZ\Shots\MARZ4_z3978\SEGOI\leg2_preshot\'); 


saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3978/processed/');
fname = checkDir([inDir,'z7978-leg2-shot-corrected.hdf']);
info = hdfinfo(fname);
corrected = (hdfread(fname,'fore'));

fname = checkDir([inDir,'z7978-leg2-shot.hdf']);
info = hdfinfo(fname);
original = (hdfread(fname,'fore'));

figure
imagesc(original)
colormap gray
colorbar
caxis([0,12e3])

figure
imagesc(corrected)
colormap gray
colorbar
caxis([0,12e3])

% get lineout at a given pixel
xpos = 800;
out_og = mean(original(:,xpos-10:xpos+10),2);
out_corr = mean(corrected(:,xpos-10:xpos+10),2);

figure
plot(out_og-700,'DisplayName','original'); hold on;
plot(out_corr,'DisplayName','corrected'); 
formatPlots(900,2);




%%

% segoi streak
clc; close all; clear;

% fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\z3697\shot_data\SEGOI\downline_data\z3697-leg1-shot.hdf');

% 

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3978/processed/');
fname = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN group/Data/Z/MARZ/Shots/MARZ4_z3978/SEGOI/shot_data/leg2/z3978-leg2-shot-corrected.hdf');
info = hdfinfo(fname);
data = hdfread(fname,'fore');

figure
imagesc(data/1e3)
% set(gca,'ColorScale','log')
colormap hot
cb = colorbar();
grid('on')
caxis([0,12000/1e3])

ylabel(cb,'Counts [\times 10^3 arb. units.]','Rotation',270)

tvals = 190:10:280;
t_px = round( (1950) / 90 * (tvals-190));

xticks(round(t_px));
xticklabels(tvals);

xlabel('time [ns]')
ylabel('x [px]')


formatPlots(700);
set(gcf,'Position',[0 0 1800 400]);


ylim([1000-600,1000+600]);
xlim([0,round( (1950) / 90 * (280-190))])

 grid on; grid('Minor');
 set(gca,'TickDir','out')

saveas(gcf, [saveDir,'leg1_streak_segoi.png']);


% Lineout vs time

out = mean(data(1000-50:1000+50,:));

figure
plot(out,LineWidth=3,color='k');
formatPlots(800,2)
grid()
xlim([0,1950])
xlabel('t [ns]')
ylabel('Intensity [arb. units]')






tvals = 190:20:280;
t_px = round( (1950) / 90 * (tvals-190));

xticks(round(t_px));
xticklabels(tvals);


legend("off")


saveas(gcf, [saveDir,'streak_layer_emission.png']);

figure

% at specific time
TID = [200,220,240];
for ii = 1:numel(TID)
tid = TID(ii);
t_px = round( (1950) / 90 * (tid-190));

out = mean(data(400:1600,t_px-25:t_px+25),2);



plot(400:1600,out,LineWidth=3,DisplayName=[num2str(tid), ' ns'],Color=sqclr('b',ii*2+1)); hold on;

grid()

end


xlim([400,1600])
xlabel('x [px]')
formatPlots(800,2)


ylabel('Intensity [arb. units]')





 

% info = hdfinfo(fname);
% img = hdfread(fname,'/image');
% xpts = h5read(fname,'/xpts');
% ypts = h5read(fname,'/ypts');
% 
% 
%  % make scatter plot
% 
%  [xx,yy] = meshgrid(xpts,ypts);
%  figure
%   colormap(gray);
%   xx = xx - 2800;
%  scatter(xx(:),yy(:),10,img(:)./max(img(:)),'s','filled','HandleVisibility','off');
%  xlim([xpts(1),xpts(end)]-2800); ylim([10.5,20]);
%  xlabel('time (ns)'); ylabel('Radius (mm)');
%  formatPlots(900,40);
%  set(gcf,'Position',[0 0 1800 600]);
% 
%  grid on; grid('Minor');
%  set(gca,'TickDir','out')
%  set(gca,'Layer','top','GridColor','r','GridAlpha',0.1,...
%     'MinorGridLineStyle','-','MinorGridColor',[.92 .51 .93],'MinorGridAlpha',0.1)
% 
%  saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3778/processed/');
% exportgraphics(gcf, [saveDir,'leg1_streak_segoi.tiff']);
% 
% save([saveDir 'segoi_streak.mat'],'img','xx','yy');
% 

%%
