

% SEGOI
clc; close all; clear;

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3778/processed/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end


fname = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN group/Data/Z/MARZ/Shots/MARZ2_z3778/SEGOI/z3778-goi-shot.hdf');


for ii = 1:8 % Read data

data{ii} = hdfread(fname,['DS', num2str(ii)]);

[m,n] = size(data{ii});

end

segoi_idx = 1:8;
frame_idx = [4,3,2,1,5,6,7,8];

% sort
segoi_idx = segoi_idx(frame_idx); 
data = data(frame_idx);

tidx = 2980+linspace(0,49,8);
gain = [128,32,8,2,64,16,4,1]; % sorted by frame
% gain = [2,8,32,128,64,16,4,1]; % sorted by frame
% gain = gain(frame_idx);

% montage(data,'Size',[2,4]); colormap('hot'); colorbar(); caxis([0,4000]);

fig = figure();
tlo = tiledlayout(fig,2,4); % Use loose to space it out
for i = 1:numel(data)
    ax = nexttile(tlo); 
    imshow(data{i});

    img = data{i};
%     minA = min(img(:));
%     A = double(img - minA) ./ double( max(img(:)) - minA);
% 

    
%     FILENAME =  [saveDir, 'GOI_frame' 1;um2str(i) '_preshot_Ret.tiff'];
%     imwrite(img,FILENAME)

    axis('off');
    colormap('hot'); colorbar(); caxis([0,4000]);

    title([num2str(tidx(i)) ' ns gain = ' num2str(gain(i)) ' GOI frame', num2str(i) ]);
end
set(gcf,'Position',[0 0 1850 750]);
sgtitle('z3697 SEGOI 8-frame Shot');

% saveas(gcf,[saveDir 'segoi_raw_8frame-preshot_Ret.png']);

%%
clc; close all;
% fig = figure();
% tlo = tiledlayout(fig,2,4); % Use loose to space it out
var = [10,10,-25,-25,-25,0,-30,-15];
for ii = 8
% ax = nexttile(tlo); 

img = data{ii};
img = double(img) / gain(ii);
img = img ./ max(img(:));
img = imrotate(img,50,'crop');


rect = [  310.5100 + var(ii)  178.5100  437.9800 + var(ii)  771.9800];
[img_c] = imcrop(img,rect);


figure
imagesc(img_c); hold on;
colormap gray
% cb = colorbar();
caxis([0.1,0.5])
axis equal
xlim([0,size(img_c,2)])
formatPlots()
legend('off')
set(gca,'TickDir','out');
title(['Frame ' num2str(ii), ' Gain = ' num2str(gain(ii)) ])
set(gca,'YDir','normal')

ogn = [220+var(ii),350];
x = [ogn(1)-162,ogn(1)+162]; % to check ogn and scale
% plot(ogn(1),ogn(2),'xr')
% plot(x,[ogn(2),ogn(2)],'or');

scale = (x(2) - x(1)) / 12; % px / mm

xvals = [-6,0,6]; % mm
yvals = -12:6:12; % mm

mm2px = @(mm) mm .* scale;
px2mm = @(px) px ./ scale;

xpx = mm2px(xvals) + ogn(1);
ypx = mm2px(yvals) + ogn(2);

xticks(round(xpx));
yticks(round(ypx));

xticklabels((xvals));
yticklabels((yvals));

xlabel('x (mm)'); ylabel('y (mm)');

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3778/processed/corrected_sub/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end
saveas(gcf,[saveDir 'fnum=' num2str(ii) '.png']);
end

