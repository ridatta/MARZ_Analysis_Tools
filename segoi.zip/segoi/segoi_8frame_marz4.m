

% SEGOI Processing Code for 2D Image Data
% R. Datta (2024)
% This code:
% (1) loads and plots the raw SEGOI images
% (2) saved the loaded images and metadata in .MAT files for further
% analysis

clc; close all; clear;

saveDir = checkDir('\Users\rishabhdatta\Dropbox (MIT)\PUFFIN\Data\MARZ\segoi\z3978\processed/'); % Save directory
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end

fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\MARZ\Shots\MARZ4_z3978\SEGOI\shot_data\goi\z3978-goi-shot.hdf'); % Shot filename


for ii = 1:8 % Read data

data{ii} = hdfread(fname,['DS', num2str(ii)]);
[m,n] = size(data{ii});

end

segoi_idx = 1:8; % Segoi number
frame_idx = [4,3,2,1,5,6,7,8]; % Frame number

% sort by frame number
segoi_idx = segoi_idx(frame_idx); 
data = data(frame_idx);

tidx = [195;195;212;212;229;229;245;245]; % set time indices [ns]

% gain = 32 * ones(1,numel(segoi_idx)); % sorted by frame
gain = [18,5,18,5,18,5,18,5]; % specify the gain, sorted by frame
% gain = gain(frame_idx);

% montage(data,'Size',[2,4]); colormap('hot'); colorbar(); caxis([0,4000]);

fig = figure();
tlo = tiledlayout(fig,2,4); % Use loose to space it out
for i = 1:numel(data)
    ax = nexttile(tlo); 
    imshow(data{i});

    img = data{i};
   
    FILENAME =  [saveDir, 'GOI_frame' num2str(i) '_shot.tiff']; % save as tiff
    imwrite(img,FILENAME)

    axis('off');
    colormap('hot'); colorbar(); caxis([0,4000]);

    title([num2str(tidx(i)) ' ns gain = ' num2str(gain(i)) ' GOI frame', num2str(i) ]);
end
set(gcf,'Position',[0 0 1850 750]);
sgtitle('z3697 SEGOI 8-frame Shot');

saveas(gcf,[saveDir 'segoi_raw_8frame_shot.png']); % save montage

save([saveDir 'segoi.mat'],'data','frame_idx','gain','tidx','segoi_idx'); % save as MAT file


%%

% This code:
% (1) loads the preshot images without reticle
% (2) saves the loaded images and metadata in .MAT files for further
% analysis


% SEGOI
clc; close all; clear;

saveDir = checkDir('\Users\rishabhdatta\Dropbox (MIT)\PUFFIN\Data\MARZ\segoi\z3978\processed/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end


fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\MARZ\Shots\MARZ4_z3978\SEGOI\shot_prep\goi\GOI-preshot-coneup-nr.hdf');


for ii = 1:8 % Read data

data{ii} = hdfread(fname,['DS', num2str(ii)]);

[m,n] = size(data{ii});

end

segoi_idx = 1:8;
frame_idx = [4,3,2,1,5,6,7,8];

% sort
segoi_idx = segoi_idx(frame_idx); 
data = data(frame_idx);

tidx = [195;195;212;212;229;229;245;245];

% gain = 32 * ones(1,numel(segoi_idx)); % sorted by frame
gain = [18,5,18,5,18,5,18,5]; % sorted by frame
% gain = gain(frame_idx);

% montage(data,'Size',[2,4]); colormap('hot'); colorbar(); caxis([0,4000]);

fig = figure();
tlo = tiledlayout(fig,2,4); % Use loose to space it out
for i = 1:numel(data)
    ax = nexttile(tlo); 
    imshow(data{i});

    img = data{i};
%     minA = min(img(:));
%     A = double(img - minA) ./ double( max(img(:)) - minA);
% 

    
    FILENAME =  [saveDir, 'GOI_frame' num2str(i) '_shot.tiff'];
    imwrite(img,FILENAME)

    axis('off');
    colormap('hot'); colorbar(); caxis([0,4000]);

    title([num2str(tidx(i)) ' ns gain = ' num2str(gain(i)) ' GOI frame', num2str(i) ]);
end
set(gcf,'Position',[0 0 1850 750]);
sgtitle('z3697 SEGOI 8-frame Pre-Shot');

saveas(gcf,[saveDir 'segoi_raw_8frame_preshot.png']);

save([saveDir 'segoi_preshot.mat'],'data','frame_idx','gain','tidx','segoi_idx');

%%

% This code:
% (1) loads the preshot images with reticle
% (2) saved the loaded images and metadata in .MAT files for further
% analysis



% SEGOI
clc; close all; clear;

saveDir = checkDir('\Users\rishabhdatta\Dropbox (MIT)\PUFFIN\Data\MARZ\segoi\z3978\processed/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end


fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\MARZ\Shots\MARZ4_z3978\SEGOI\shot_prep\goi\GOI-preshot-coneup-ret.hdf');


for ii = 1:8 % Read data

data{ii} = hdfread(fname,['DS', num2str(ii)]);

[m,n] = size(data{ii});

end

segoi_idx = 1:8;
frame_idx = [4,3,2,1,5,6,7,8];

% sort
segoi_idx = segoi_idx(frame_idx); 
data = data(frame_idx);

tidx = [195;195;212;212;229;229;245;245];

% gain = 32 * ones(1,numel(segoi_idx)); % sorted by frame
gain = [18,5,18,5,18,5,18,5]; % sorted by frame
% gain = gain(frame_idx);

% montage(data,'Size',[2,4]); colormap('hot'); colorbar(); caxis([0,4000]);

fig = figure();
tlo = tiledlayout(fig,2,4); % Use loose to space it out
for i = 1:numel(data)
    ax = nexttile(tlo); 
    imshow(data{i});

    img = data{i};
%     minA = min(img(:));
%     A = double(img - minA) ./ double( max(img(:)) - minA);
% 

    
    FILENAME =  [saveDir, 'GOI_frame' num2str(i) '_shot.tiff'];
    imwrite(img,FILENAME)

    axis('off');
    colormap('hot'); colorbar(); caxis([0,4000]);

    title([num2str(tidx(i)) ' ns gain = ' num2str(gain(i)) ' GOI frame', num2str(i) ]);
end
set(gcf,'Position',[0 0 1850 750]);
sgtitle('z3697 SEGOI 8-frame Pre-Shot');

saveas(gcf,[saveDir 'segoi_raw_8frame_preshot_ret.png']);

save([saveDir 'segoi_preshot_ret.mat'],'data','frame_idx','gain','tidx','segoi_idx');



%%

% This section:
% (1) Rotates and scales the shot images based on the preshot images
% (2) Saves  the rotated images

clc; close all; clear;

saveDir = checkDir('\Users\rishabhdatta\Dropbox (MIT)\PUFFIN\Data\MARZ\segoi\z3978\processed/');

new = true;

load([saveDir 'segoi.mat'],'data','frame_idx','segoi_idx','rotation_angles','scale','ogn'); % load data and calibration


% Load shot and preshot data
for fnum = 1:8
shot = data;

load([saveDir 'segoi_preshot.mat'],'data','frame_idx','segoi_idx');
preshot= data;

load([saveDir 'segoi_preshot_ret.mat'],'data','frame_idx','segoi_idx');
preshot_ret= data;


% Show pre-shot image
f1 = figure()
imshow(preshot{fnum}); 
title(['SEGOI Pre-shot, Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',24);
axis('off'); colormap(gray);
grid();
set(gca,'TickDir','out')
formatPlots(1000)
colorbar(); caxis([0,1e3]); hold on;


% (1) Select points for alignment and scale
if new == true
    [Xi,Yi] = getpts(); % select 2 points on lower edge
    plot(Xi(1),Yi(1),'xg','HandleVisibility','off','MarkerSize',10); hold on;
    plot(Xi(2),Yi(2),'xg','HandleVisibility','off','MarkerSize',10); hold on;
    plot(Xi(2),Yi(1),'xg','HandleVisibility','off','MarkerSize',10); hold on;
    plot([Xi(1),Xi(2)],[Yi(1),Yi(2)],'-c','HandleVisibility','off');
    plot([Xi(1),Xi(2)],[Yi(1),Yi(1)],'-c','HandleVisibility','off');
    % plot([Xi(1),Xi(3)],[Yi(1),Yi(3)],'-m','HandleVisibility','off');
    
    % Caluclate angle
    th1 = atand( (Yi(2) - Yi(1)) ./ (Xi(2) - Xi(1))); % deg,
    
    text(Xi(1),Yi(1),...
        [num2str(th1,3), ' deg'],'Color','c','FontSize',16);
    
    % save
    rotation_angles{fnum} = (th1-15) - 90; % rotation angle
    saveas(gcf,[saveDir 'segoi_preshot_fnum=' num2str(fnum) '.png']);
else
    load([saveDir 'segoi.mat'],'rotation_angles');
    
end



% rotate and show
preshot_rotated{fnum} = imrotate(preshot{fnum},rotation_angles{fnum},'crop');


f2 = figure()
imagesc(preshot_rotated{fnum}); 
title(['SEGOI Pre-shot (Rotated), Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',24);
colormap(hot);
formatPlots(1000);
grid();
ax = gca; % Get handle to current axes.
ax.GridAlpha = 0.4;  % Make grid lines less transparent.
ax.GridColor = [1,1,1];
set(gca,'TickDir','out')
colorbar(); caxis([0,2e3]); hold on;

% (2) get scale

if new == true
    title('Diameter = ?')
    [Xj,Yj] = getpts(); % select diameter of cyclinder
    
    plot([Xj(1),Xj(2)],[Yj(1),Yj(1)],'-c','HandleVisibility','off');
    text(mean([Xj(1),Xj(2)]),mean([Yj(1),Yj(1)]),'4.78 mm','Color','c','FontSize',24);
        
    
    d_known = 4.7752; % mm, known diameter of the cylinder
    d_px = Xj(2)-Xj(1); % px
    scale{fnum} = d_known / d_px; % mm / px

    text(mean([Xj(1),Xj(2)]),-50+mean([Yj(1),Yj(1)]),[num2str(scale{fnum},3) ' mm/px']...
        ,'Color','c','FontSize',24);
    

    title('')
    saveas(gcf,[saveDir 'segoi_preshot_scale_fnum=' num2str(fnum) '.png']);
else
        load([saveDir 'segoi.mat'],'scale');
end


% (3) get ogn form reticle image; select the center of the reticle



preshot_ret_rotated{fnum} = imrotate(preshot_ret{fnum},rotation_angles{fnum},'crop');


f3 = figure()
imagesc(preshot_ret_rotated{fnum}); 
title(['SEGOI Pre-shot (Rotated), Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',24);
colormap(hot);
formatPlots(1000);
grid();
ax = gca; % Get handle to current axes.
ax.GridAlpha = 0.4;  % Make grid lines less transparent.
ax.GridColor = [1,1,1];
set(gca,'TickDir','out')
colorbar(); caxis([0,1e3]); hold on;


if new
 title('Origin = ?')
    [Xk,Yk] = getpts(); %  select the center of the reticle
    ogn{fnum} = [Xk,Yk];
else
            load([saveDir 'segoi.mat'],'ogn');
end



figure(f2)
axis("equal");
ax.GridAlpha = 0.2;  % Make grid lines less transparent.

% change axis labels
xvals_mm = -6:2:6; % mm
xvals_px = xvals_mm / scale{fnum} + ogn{fnum}(1); % px
xticks(xvals_px); 
xticklabels(xvals_mm); 
xlim([min(xvals_px),max(xvals_px)]);

yvals_mm = -6:2:6; % mm
yvals_px = yvals_mm / scale{fnum} + ogn{fnum}(2); % px
yticks(yvals_px); 
yticklabels(yvals_mm); 
ylim([min(yvals_px),max(yvals_px)]);

xlabel('x [mm]')
ylabel('y [mm]')


saveas(gcf,[saveDir 'segoi_preshot_calib_fnum=' num2str(fnum) '.png']);

% close all;


end


% save as MAT

load([saveDir 'segoi.mat'],'data','frame_idx','segoi_idx');
save([saveDir 'segoi.mat'],'data','frame_idx','segoi_idx','rotation_angles','scale','ogn');


%% Calibrated Shot images

clc; close all; clear;


saveDir = checkDir('\Users\rishabhdatta\Dropbox (MIT)\PUFFIN\Data\MARZ\segoi\z3978\processed/');

load([saveDir 'segoi.mat'],'data','frame_idx','segoi_idx','rotation_angles','scale','ogn'); % load data and calibration



for fnum = 1:8

img = data{fnum};
img_rotated{fnum} = imrotate(img,rotation_angles{fnum},'crop');


% Show shot image
figure
imagesc(img_rotated{fnum}); 
title(['SEGOI Shot (Rotated), Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',24);
colormap(hot);
formatPlots(1000);
grid();
ax = gca; % Get handle to current axes.
ax.GridAlpha = 0.1;  % Make grid lines less transparent.
ax.GridColor = 0.6*[1,1,1];
set(gca,'TickDir','out')
colorbar(); caxis([0,4e3]); hold on;
axis('equal')

% change axis labels
xvals_mm = -6:2:6; % mm
xvals_px = xvals_mm / scale{fnum} + ogn{fnum}(1) - 0.4 / scale{fnum}; % px
xticks(xvals_px); 
xticklabels(xvals_mm); 
xlim([min(xvals_px),max(xvals_px)]);

yvals_mm = -6:2:6; % mm
yvals_px = yvals_mm / scale{fnum} + ogn{fnum}(2); % px
yticks(yvals_px); 
yticklabels(-1*yvals_mm); 
ylim([min(yvals_px),max(yvals_px)]);

xlabel('x [mm]')
ylabel('y [mm]')


saveas(gcf,[saveDir 'segoi_shot_calib_fnum=' num2str(fnum) '.png']);

save([saveDir 'segoi.mat'],'data','frame_idx','segoi_idx','rotation_angles','scale','ogn','img_rotated'); % load data and calibration

end


%% Show all images


clc; close all; clear;

saveDir = checkDir('\Users\rishabhdatta\Dropbox (MIT)\PUFFIN\Data\MARZ\segoi\z3978\processed/');
load([saveDir 'segoi.mat']); % load data and calibration

tidx = [195;195;212;212;229;229;245;245];
gain = [18,5,18,5,18,5,18,5]; % sorted by frame

idx = [2,4,6,8,1,3,5,7];


fig = figure();
tlo = tiledlayout(fig,2,4); % Use loose to space it out
count = 1;
for fnum = idx
    ax = nexttile(tlo); 

    imagesc(img_rotated{fnum}); 
    set(gca,'FontSize',24);
    colormap(hot);
    formatPlots(400);
    grid();
    ax = gca; % Get handle to current axes.
    ax.GridAlpha = 0.1;  % Make grid lines less transparent.
    ax.GridColor = 0.8*[1,1,1];
    set(gca,'TickDir','out')
    colorbar();
    if mod(fnum,2) == 0
        caxis([0,4e3]);
    else
    caxis([0,4e3]);
    end
    hold on;
    axis('equal')

    % change axis labels
    xvals_mm = -6:2:6; % mm
    xvals_px = xvals_mm / scale{fnum} + ogn{fnum}(1) - 0.4 / scale{fnum}; % px
    xticks(xvals_px); 
    xticklabels(xvals_mm); 
    xlim([min(xvals_px),max(xvals_px)]);
    
    yvals_mm = -6:2:6; % mm
    yvals_px = yvals_mm / scale{fnum} + ogn{fnum}(2); % px
    yticks(yvals_px); 
    yticklabels(-1*yvals_mm); 
    ylim([min(yvals_px),max(yvals_px)]);
    
    xlabel('x [mm]')
    ylabel('z [mm]')

    if count - 4 <= 0
        xticklabels("")
        xlabel("")
        title([num2str(tidx(fnum)) ' ns']);
    end

    if ~(count == 1 || count == 5)
         yticklabels("")
        ylabel("")
    end

    if ~(mod(count,4) == 0)
        colorbar("off");
    end


% 

    
    formatPlots(600)
    count = count + 1;
end
set(gcf,'Position',[0 0 1200 800]*2);

saveas(gcf,[saveDir 'segoi_shot.png']);
% sgtitle('z3697 SEGOI 8-frame Shot');


%% For thesis


clc; close all; clear;

saveDir = checkDir('\Users\rishabhdatta\Dropbox (MIT)\PUFFIN\Data\MARZ\segoi\z3978\processed/');
load([saveDir 'segoi.mat']); % load data and calibration

tidx = [195;195;212;212;229;229;245;245];
gain = [18,5,18,5,18,5,18,5]; % sorted by frame

idx = [2,4,6,8,1,3,5,7];


fig = figure();
tlo = tiledlayout(fig,1,2); % Use loose to space it out
count = 1;
for fnum = [1,8]
    ax = nexttile(tlo); 

    imagesc(img_rotated{fnum}); 
    set(gca,'FontSize',24);
    colormap(hot);
    formatPlots(400);
    grid();
    ax = gca; % Get handle to current axes.
    ax.GridAlpha = 0.1;  % Make grid lines less transparent.
    ax.GridColor = 0.8*[1,1,1];
    set(gca,'TickDir','out')
    colorbar();
    if mod(fnum,2) == 0
        caxis([0,4e3]);
    else
    caxis([0,4e3]);
    end
    hold on;
    axis('equal')

    % change axis labels
    xvals_mm = -6:2:6; % mm
    xvals_px = xvals_mm / scale{fnum} + ogn{fnum}(1) - 0.4 / scale{fnum}; % px
    xticks(xvals_px); 
    xticklabels(xvals_mm); 
    xlim([min(xvals_px),max(xvals_px)]);
    
    yvals_mm = -6:2:6; % mm
    yvals_px = yvals_mm / scale{fnum} + ogn{fnum}(2); % px
    yticks(yvals_px); 
    yticklabels(-1*yvals_mm); 
    ylim([min(yvals_px),max(yvals_px)]);
    
    xlabel('x [mm]')
    ylabel('z [mm]')

    if count - 4 <= 0
        % xticklabels("")
        % xlabel("")
        title([num2str(tidx(fnum)) ' ns']);
    end

    if ~(count == 1 || count == 5)
         yticklabels("")
        ylabel("")
    end

    if ~(mod(count,4) == 0)
        colorbar("off");
    end


% 

    
    formatPlots(600)
    count = count + 1;
end
set(gcf,'Position',[0 0 1200 800]*2);

saveas(gcf,[saveDir 'segoi_shot.png']);


%% Rough calibration
clc; close all;
% fig = figure();
% tlo = tiledlayout(fig,2,4); % Use loose to space it out
var = 0*[10,0,-25,-25,-25,0,-30,-15];
for ii = 1:8
% ax = nexttile(tlo); 

img = data{ii};
img = double(img) / gain(ii);
img = img ./ max(img(:));

if ii < 5
img = imrotate(img,90+16.5,'crop'); % rotate
else
img = imrotate(img,90+16.5+5,'crop'); % rotate
end




% rect = [  310.5100 + var(ii)  120  470 + var(ii)  740];
% [img_c] = imcrop(img,rect);

img_c = img;


figure
imagesc(img_c); hold on;
colormap hot
% cb = colorbar();
if mod(ii,2) == 0
    caxis([0,0.7])
else
    caxis([0,1.0])
end
axis equal

% detect boundary 
[Cx,Rx,P] = impixel();
[Cy,Ry,P] = impixel();


formatPlots()
legend('off')
set(gca,'TickDir','out');
title(['Frame ' num2str(ii), ' Gain = ' num2str(gain(ii)) ])
set(gca,'YDir','normal')


% plot(x,[ogn(2),ogn(2)],'or');

scale = (Cx(2) - Cx(1)) / 11; % px / mm
ogn = [Cx(1)+(Cx(2)-Cx(1))/2; Ry(1)+(Ry(2)-Ry(1))/2];
plot(ogn(1),ogn(2),'x')

xvals = [-5,0,5]; % mm
yvals = [-5,0,5]; % mm

mm2px = @(mm) mm .* scale;
px2mm = @(px) px ./ scale;

xpx = mm2px(xvals) + ogn(1);
ypx = mm2px(yvals) + ogn(2);

xticks(round(xpx));
yticks(round(ypx));

xticklabels((xvals));
yticklabels((yvals));

xlabel('x (mm)'); ylabel('z (mm)');

xlim([Cx(1), Cx(2)])
ylim([Ry(1), Ry(2)])

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3978/processed/corrected/');
if ~exist(saveDir,'dir')
    mkdir(saveDir)
end
saveas(gcf,[saveDir 'fnum=' num2str(ii) '.png']);
end


%% Lineouts

clc; close all; clear;

saveDir = checkDir('\Users\rishabhdatta\Dropbox (MIT)\PUFFIN\Data\MARZ\segoi\z3978\processed/');
load([saveDir 'segoi.mat']); % load data and calibration


fnum = 1;
figure
imagesc(img_rotated{fnum}); 

title(['SEGOI Shot (Rotated), Frame ' num2str(fnum), ' GOI' num2str(segoi_idx(fnum))]);
set(gca,'FontSize',24);
colormap(hot);
formatPlots(1000);
grid();
ax = gca; % Get handle to current axes.
ax.GridAlpha = 0.1;  % Make grid lines less transparent.
ax.GridColor = 0.6*[1,1,1];
set(gca,'TickDir','out')
colorbar(); caxis([0,4e3]); hold on;
axis('equal')

% change axis labels
xvals_mm = -6:2:6; % mm
xvals_px = xvals_mm / scale{fnum} + ogn{fnum}(1) - 0.4 / scale{fnum}; % px
xticks(xvals_px); 
xticklabels(xvals_mm); 
xlim([min(xvals_px),max(xvals_px)]);

yvals_mm = -6:2:6; % mm
yvals_px = yvals_mm / scale{fnum} + ogn{fnum}(2); % px
yticks(yvals_px); 
yticklabels(-1*yvals_mm); 
ylim([min(yvals_px),max(yvals_px)]);

xlabel('x [mm]')
ylabel('z [mm]')


figure
Z = [-3,0,3];
for ii = 1:numel(Z)
zq = Z(ii);

zq_px = round(zq / scale{fnum} + ogn{fnum}(2));

out = img_rotated{fnum}(zq_px-30:zq_px+30,:);
out = mean(out,1);

x_px = 1:numel(out);
x_mm = (x_px - (ogn{fnum}(1) - 0.4 / scale{fnum})) * scale{fnum};


plot(x_mm, out,LineWidth=3,DisplayName=['z = ', num2str(-1*zq) ' mm']); hold on;
xlabel('x [mm]');
ylabel('Counts [arb. units]')
formatPlots(800,2);
xlim([-4,4]);
xticks(-4:2:4)
grid();
legend('box','on')
end

saveas(gcf,[saveDir 'Lineouts_fnum=' num2str(fnum) '.png']);


