% segoi streak
clc; close all; clear;

% fname = checkDir('\Users\rdatta\Dropbox (MIT)\PUFFIN group\Data\Z\z3697\shot_data\SEGOI\downline_data\z3697-leg1-shot.hdf');

% 

saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3781/processed/');
fname = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN group/Data/Z/MARZ/Shots/MARZ3_z3781/SEGOI/z3781-leg1-shot-corrected.hdf');
info = hdfinfo(fname);
data = hdfread(fname,'fore');

figure
imagesc(data)
colormap gray
colorbar
caxis([0,2000])

imwrite(data, [saveDir,'leg1_streak_segoi.tiff']);
 

% % info = hdfinfo(fname);
% % img = hdfread(fname,'/image');
% % xpts = h5read(fname,'/xpts');
% % ypts = h5read(fname,'/ypts');
%  
%  
%  % make scatter plot
%  
%  [xx,yy] = meshgrid(xpts,ypts);
%  figure
%   colormap(gray);
%   xx = xx - 2800;
%  scatter(xx(:),yy(:),10,img(:)./max(img(:)),'s','filled','HandleVisibility','off');
%  xlim([xpts(1),xpts(end)]-2800); ylim([10.5,20]);
%  xlabel('time (ns)'); ylabel('Radius (mm)');
%  formatPlots(900,40);
%  set(gcf,'Position',[0 0 1800 600]);
%  
%  grid on; grid('Minor');
%  set(gca,'TickDir','out')
%  set(gca,'Layer','top','GridColor','r','GridAlpha',0.1,...
%     'MinorGridLineStyle','-','MinorGridColor',[.92 .51 .93],'MinorGridAlpha',0.1)
% 
%  saveDir = checkDir('/Users/rishabhdatta/Dropbox (MIT)/PUFFIN/Data/MARZ/segoi/z3778/processed/');
% exportgraphics(gcf, [saveDir,'leg1_streak_segoi.tiff']);
% 
% save([saveDir 'segoi_streak.mat'],'img','xx','yy');
